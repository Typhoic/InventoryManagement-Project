let orders = [];

window.onload = () => {
    const saved = localStorage.getItem("orders");
    if (saved) {
        orders = JSON.parse(saved);
        renderTable();
    }
};

function save() {
    localStorage.setItem("orders", JSON.stringify(orders));
}

/* Indonesian number formatter with thousand separators */
function formatRupiah(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function formatPriceInput() {
    let input = document.getElementById("totalPrice");
    let value = input.value.replace(/\D/g, "");
    input.value = value ? formatRupiah(value) : "";
}

function openPopup() { document.getElementById("popupForm").style.display = "flex"; }
function closePopup() { document.getElementById("popupForm").style.display = "none"; }

function addOrder() {
    let rawPrice = document.getElementById("totalPrice").value.replace(/\./g, "");

    const order = {
        orderNumber: document.getElementById("orderNumber").value,
        orderDateTime: document.getElementById("orderDateTime").value,
        orderedFood: document.getElementById("orderedFood").value,
        totalPrice: parseInt(rawPrice),
        orderID: document.getElementById("orderID").value
    };

    if (!order.orderNumber || !order.orderDateTime || !order.orderedFood || !order.totalPrice || !order.orderID) {
        alert("Please fill in all fields.");
        return;
    }

    orders.push(order);
    save();
    renderTable();
    closePopup();

    document.getElementById("orderNumber").value = "";
    document.getElementById("orderDateTime").value = "";
    document.getElementById("orderedFood").value = "";
    document.getElementById("totalPrice").value = "";
    document.getElementById("orderID").value = "";
}

function deleteOrder(i) {
    orders.splice(i, 1);
    save();
    renderTable();
}

function renderTable() {
    const tbody = document.querySelector("#orderTable tbody");
    tbody.innerHTML = "";

    orders.forEach((o, i) => {
        tbody.innerHTML += `
            <tr>
                <td>${o.orderNumber}</td>
                <td>${o.orderDateTime.replace("T", " ")}</td>
                <td>${o.orderedFood}</td>
                <td>Rp.${formatRupiah(o.totalPrice)},00-</td>
                <td>${o.orderID}</td>
                <td><button class="delete-btn" onclick="deleteOrder(${i})">Cancel</button></td>
            </tr>
        `;
    });
}

function searchOrder() {
    const q = document.getElementById("searchBar").value.toLowerCase();
    document.querySelectorAll("#orderTable tbody tr").forEach(row => {
        const orderID = row.cells[4].textContent.toLowerCase();
        row.style.display = orderID.includes(q) ? "" : "none";
    });
}

function sortByDateOption(mode) {
    if (mode === "asc") {
        orders.sort((a, b) => new Date(a.orderDateTime) - new Date(b.orderDateTime));
    } else if (mode === "desc") {
        orders.sort((a, b) => new Date(b.orderDateTime) - new Date(a.orderDateTime));
    }
    save();
    renderTable();
}

function sortByOrderIDOption(mode) {
    if (mode === "asc") {
        orders.sort((a, b) => a.orderID.localeCompare(b.orderID));
    } else if (mode === "desc") {
        orders.sort((a, b) => b.orderID.localeCompare(a.orderID));
    }
    save();
    renderTable();
}
