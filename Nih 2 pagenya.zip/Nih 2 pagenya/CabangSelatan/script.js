let items = [];
let selectedImage = ""; // Base64 for new item image

window.onload = () => {
    const saved = localStorage.getItem("items");
    if (saved) {
        items = JSON.parse(saved);
        renderTable();
    }

    const imgInput = document.getElementById("itemImage");
    imgInput.addEventListener("change", function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                selectedImage = e.target.result; // Base64
            }
            reader.readAsDataURL(file);
        }
    });
};

function save() {
    localStorage.setItem("items", JSON.stringify(items));
}

function formatRupiah(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function formatPriceInput() {
    let input = document.getElementById("itemPrice");
    let value = input.value.replace(/\D/g, "");
    input.value = value ? formatRupiah(value) : "";
}

function openPopup() { document.getElementById("popupForm").style.display = "flex"; }
function closePopup() { document.getElementById("popupForm").style.display = "none"; }

function addItem() {
    let rawPrice = document.getElementById("itemPrice").value.replace(/\./g, "");

    const item = {
        itemNumber: document.getElementById("itemNumber").value,
        itemName: document.getElementById("itemName").value,
        itemType: document.getElementById("itemType").value,
        itemPrice: parseInt(rawPrice),
        itemDesc: document.getElementById("itemDesc").value,
        itemImage: selectedImage || ""
    };

    if (!item.itemNumber || !item.itemName || !item.itemType || !item.itemPrice) {
        alert("Please fill in all required fields.");
        return;
    }

    items.push(item);
    save();
    renderTable();
    closePopup();

    // Reset
    document.getElementById("itemNumber").value = "";
    document.getElementById("itemName").value = "";
    document.getElementById("itemType").value = "";
    document.getElementById("itemPrice").value = "";
    document.getElementById("itemDesc").value = "";
    document.getElementById("itemImage").value = "";
    selectedImage = "";
}

function deleteItem(i) {
    items.splice(i, 1);
    save();
    renderTable();
}

function renderTable() {
    const tbody = document.querySelector("#itemTable tbody");
    tbody.innerHTML = "";

    items.forEach((item, i) => {
        tbody.innerHTML += `
            <tr>
                <td>${item.itemNumber}</td>
                <td><img src="${item.itemImage || ''}" alt="Icon" class="item-icon"></td>
                <td>${item.itemName}</td>
                <td>${item.itemType}</td>
                <td>Rp.${formatRupiah(item.itemPrice)},00-</td>
                <td>${item.itemDesc}</td>
                <td><button class="delete-btn" onclick="deleteItem(${i})">Delete</button></td>
            </tr>
        `;
    });
}

function searchItem() {
    const q = document.getElementById("searchBar").value.toLowerCase();
    document.querySelectorAll("#itemTable tbody tr").forEach(row => {
        const name = row.cells[2].textContent.toLowerCase();
        row.style.display = name.includes(q) ? "" : "none";
    });
}

function sortItems(option) {
    switch(option) {
        case "name-asc": items.sort((a,b) => a.itemName.localeCompare(b.itemName)); break;
        case "name-desc": items.sort((a,b) => b.itemName.localeCompare(a.itemName)); break;
        case "type-asc": items.sort((a,b) => a.itemType.localeCompare(b.itemType)); break;
        case "type-desc": items.sort((a,b) => b.itemType.localeCompare(a.itemType)); break;
        case "price-asc": items.sort((a,b) => a.itemPrice - b.itemPrice); break;
        case "price-desc": items.sort((a,b) => b.itemPrice - a.itemPrice); break;
    }
    save();
    renderTable();
}
